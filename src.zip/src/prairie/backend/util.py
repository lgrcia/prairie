def clean_prairie_id(id):
    return '_' + id.replace('-', '_')