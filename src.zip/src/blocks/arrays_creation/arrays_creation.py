import numpy as np

def ones(n):
    return np.ones(n)
    
def ones_like(n):
    return np.ones_like(n)

def zeros(n):
    return np.zeros(n)

def zeros_like(n):
    return np.zeros_like(n)

def empty(n):
    return np.empty(n)

def empty_like(n):
    return np.empty_like(n)

def eye(n,m,k):
    e = np.eye(n, m, k)
    return e

