var libraries = {
    basics: {
        path: '/Users/lgr/Code/prairie-vue/src/blocks/basics'
    },
    operations: {
        path: '/Users/lgr/Code/prairie-vue/src/blocks/operations'
    },
    logics: {
        path: '/Users/lgr/Code/prairie-vue/src/blocks/arrays'
    },
    arrays: {
        path: '/Users/lgr/Code/prairie-vue/src/blocks/logics'
    },
    signals: {
        path: '/Users/lgr/Code/prairie-vue/src/blocks/signals'
    },
    arrays_creation: {
        path: '/Users/lgr/Code/prairie-vue/src/blocks/arrays_creation'
    },
}

export {
    libraries
}