import numpy as np

def sin(x):
    return np.sin(x)

def cos(x):
    return np.cos(x)

def tan(x):
    return np.tan(x)

def normal(mu, sigma, n):
    return np.random.normal(mu, sigma, n)