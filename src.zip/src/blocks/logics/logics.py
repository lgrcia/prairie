def OR(a, b):
    return a or b

def AND(a, b):
    return a and b

def NOT(a):
    return not a
